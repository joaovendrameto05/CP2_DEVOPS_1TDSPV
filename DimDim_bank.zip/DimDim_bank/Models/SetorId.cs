﻿namespace DimDimAPI.Models
{
    public class Setor
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public int QtdColaboradores { get; set; }
        public decimal OrcamentoAnual { get; set; }
        public string GestorResponsavel { get; set; }
    }
}