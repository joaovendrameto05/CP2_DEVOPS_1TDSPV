﻿namespace DimDimAPI.Models
{
    public class Transacao
    {
        public int Id { get; set; }
        public string Descricao { get; set; }
        public decimal Valor { get; set; }
        public DateTime Data { get; set; }

        // Chave estrangeira para o Setor
        public int SetorId { get; set; }
    }
}