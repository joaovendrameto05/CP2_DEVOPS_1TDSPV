﻿using Microsoft.EntityFrameworkCore;
using DimDimAPI.Models;

namespace DimDimAPI.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Transacao> Transacoes { get; set; }
        public DbSet<Setor> Setores { get; set; } // Mudança de Categorias para Setores

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Garante que o Entity Framework mapeie para os nomes corretos das tabelas
            modelBuilder.Entity<Transacao>().ToTable("Transacoes");
            modelBuilder.Entity<Setor>().ToTable("Setores");
        }
    }
}